package com.atcs.finalproject.grp8.ServiceImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.atcs.finalproject.grp8.Entity.CurrentAcc;
import com.atcs.finalproject.grp8.Entity.SavingAcc;
import com.atcs.finalproject.grp8.Repo.currentRepo;
import com.atcs.finalproject.grp8.Repo.savingRepo;
import com.atcs.finalproject.grp8.Services.SavingService;

@Component

public class SavingAccserimpl  implements SavingService{
	@Autowired
	savingRepo sr1;

	@Override
	public List<SavingAcc> getdata() {
		// TODO Auto-generated method stub
		return sr1.findAll();
	}

	@Override
	public SavingAcc getdatabyid(long Acc_noS) {
		// TODO Auto-generated method stub
		SavingAcc s= sr1.findById( Acc_noS).get();
		return s;
		
		
	}

	@Override
	public List<SavingAcc> postdata(SavingAcc s) {
		// TODO Auto-generated method stub
		sr1.save(s);
		return sr1.findAll();
		
	}

	@Override
	public List<SavingAcc> putdata(SavingAcc s) {
		// TODO Auto-generated method stub
		sr1.save(s);
		return sr1.findAll();
		
	}

	

	@Override
	public List<SavingAcc> deletedata(long Acc_noS) {
		// TODO Auto-generated method stub
		sr1.deleteById(Acc_noS);
		return sr1.findAll();
		
		
	}

}
