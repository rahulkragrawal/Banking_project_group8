package com.atcs.finalproject.grp8.ServiceImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.atcs.finalproject.grp8.Entity.CurrentAcc;
import com.atcs.finalproject.grp8.Repo.currentRepo;
import com.atcs.finalproject.grp8.Services.currentAccservices;

@Component

public class currentAccimpl  implements currentAccservices{
	@Autowired
	currentRepo cr1;

	@Override
	public List<CurrentAcc> getdata() {
		// TODO Auto-generated method stub
		return cr1.findAll();
	}

	@Override
	public CurrentAcc getdatabyid(long Acc_noC) {
		// TODO Auto-generated method stub
		CurrentAcc c= cr1.findById( Acc_noC).get();
		return c;
		
		
	}

	@Override
	public List<CurrentAcc> postdata(CurrentAcc c) {
		// TODO Auto-generated method stub
		cr1.save(c);
		return cr1.findAll();
		
	}

	@Override
	public List<CurrentAcc> putdata(CurrentAcc c) {
		// TODO Auto-generated method stub
		cr1.save(c);
		return cr1.findAll();
		
	}

	

	@Override
	public List<CurrentAcc> deletedata(long Acc_noC) {
		// TODO Auto-generated method stub
		cr1.deleteById(Acc_noC);
		return cr1.findAll();
		
		
	}

}
